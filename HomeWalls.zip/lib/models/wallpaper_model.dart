class WallpaperModel {
  final String id;
  final String wallpaperCode;
  final String url;
  final String category;
  final List<String> tags;
  final String? description;
  final DateTime createdAt;
  final int downloads;

  WallpaperModel({
    required this.id,
    required this.wallpaperCode,
    required this.url,
    required this.category,
    required this.tags,
    this.description,
    required this.createdAt,
    this.downloads = 0,
  });

  factory WallpaperModel.fromMap(Map<String, dynamic> map, String id) {
    return WallpaperModel(
      id: id,
      wallpaperCode: map['wallpaper_code'] ?? '',
      url: map['url'] ?? '',
      category: map['category'] ?? '',
      tags: List<String>.from(map['tags'] ?? []),
      description: map['description'],
      createdAt: DateTime.fromMillisecondsSinceEpoch(
        map['created_at']?.millisecondsSinceEpoch ?? 0,
      ),
      downloads: map['downloads'] ?? 0,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'wallpaper_code': wallpaperCode,
      'url': url,
      'category': category,
      'tags': tags,
      'description': description,
      'created_at': createdAt,
      'downloads': downloads,
    };
  }
}