import 'package:flutter/material.dart';

class CategoryCard extends StatelessWidget {
  final String category;
  final VoidCallback onTap;

  const CategoryCard({
    super.key,
    required this.category,
    required this.onTap,
  });

  IconData _getCategoryIcon(String category) {
    switch (category.toLowerCase()) {
      case 'minimal':
        return Icons.minimize;
      case 'abstract':
        return Icons.blur_on;
      case 'anime':
        return Icons.animation;
      case 'nature':
        return Icons.nature;
      case 'space':
        return Icons.rocket_launch;
      case 'cars':
        return Icons.directions_car;
      case 'gaming':
        return Icons.games;
      case 'technology':
        return Icons.computer;
      default:
        return Icons.image;
    }
  }

  Color _getCategoryColor(String category) {
    switch (category.toLowerCase()) {
      case 'minimal':
        return Colors.grey;
      case 'abstract':
        return Colors.purple;
      case 'anime':
        return Colors.pink;
      case 'nature':
        return Colors.green;
      case 'space':
        return Colors.indigo;
      case 'cars':
        return Colors.red;
      case 'gaming':
        return Colors.orange;
      case 'technology':
        return Colors.blue;
      default:
        return Colors.teal;
    }
  }

  @override
  Widget build(BuildContext context) {
    final color = _getCategoryColor(category);
    final icon = _getCategoryIcon(category);

    return Card(
      elevation: 4,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(16),
        child: Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(16),
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [
                color.withOpacity(0.8),
                color,
              ],
            ),
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(
                icon,
                size: 40,
                color: Colors.white,
              ),
              const SizedBox(height: 8),
              Text(
                category,
                style: const TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w600,
                  color: Colors.white,
                ),
                textAlign: TextAlign.center,
              ),
            ],
          ),
        ),
      ),
    );
  }
}