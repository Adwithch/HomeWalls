import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/wallpaper_model.dart';

class WallpaperProvider extends ChangeNotifier {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  
  List<WallpaperModel> _wallpapers = [];
  List<WallpaperModel> _categoryWallpapers = [];
  List<String> _categories = [];
  bool _isLoading = false;
  String? _error;

  List<WallpaperModel> get wallpapers => _wallpapers;
  List<WallpaperModel> get categoryWallpapers => _categoryWallpapers;
  List<String> get categories => _categories;
  bool get isLoading => _isLoading;
  String? get error => _error;

  Future<void> fetchCategories() async {
    try {
      _isLoading = true;
      _error = null;
      notifyListeners();

      final snapshot = await _firestore
          .collection('wallpapers')
          .get();

      final Set<String> categorySet = {};
      for (var doc in snapshot.docs) {
        final data = doc.data();
        if (data['category'] != null) {
          categorySet.add(data['category']);
        }
      }

      _categories = categorySet.toList()..sort();
      _isLoading = false;
      notifyListeners();
    } catch (e) {
      _error = e.toString();
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<void> fetchWallpapersByCategory(String category) async {
    try {
      _isLoading = true;
      _error = null;
      notifyListeners();

      final snapshot = await _firestore
          .collection('wallpapers')
          .where('category', isEqualTo: category)
          .orderBy('created_at', descending: true)
          .get();

      _categoryWallpapers = snapshot.docs
          .map((doc) => WallpaperModel.fromMap(doc.data(), doc.id))
          .toList();

      _isLoading = false;
      notifyListeners();
    } catch (e) {
      _error = e.toString();
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<WallpaperModel?> searchByCode(String code) async {
    try {
      _isLoading = true;
      _error = null;
      notifyListeners();

      final snapshot = await _firestore
          .collection('wallpapers')
          .where('wallpaper_code', isEqualTo: code.toUpperCase())
          .limit(1)
          .get();

      _isLoading = false;
      notifyListeners();

      if (snapshot.docs.isNotEmpty) {
        return WallpaperModel.fromMap(
          snapshot.docs.first.data(),
          snapshot.docs.first.id,
        );
      }
      return null;
    } catch (e) {
      _error = e.toString();
      _isLoading = false;
      notifyListeners();
      return null;
    }
  }

  Future<void> incrementDownloadCount(String wallpaperId) async {
    try {
      await _firestore
          .collection('wallpapers')
          .doc(wallpaperId)
          .update({
        'downloads': FieldValue.increment(1),
      });
    } catch (e) {
      debugPrint('Error incrementing download count: $e');
    }
  }
}