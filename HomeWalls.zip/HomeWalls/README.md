# HomeWalls - Flutter Wallpaper App

A beautiful wallpaper app built with Flutter, featuring Firebase backend integration and ad monetization.

## Features

### 🎨 Core Features
- **Dynamic Wallpaper Categories**: Browse wallpapers by categories (Minimal, Abstract, Anime, Nature, etc.)
- **Search by Code**: Find specific wallpapers using unique codes (e.g., WALL123)
- **Download & Set Wallpapers**: Download to gallery or set as home/lock screen wallpaper
- **Firebase Integration**: Real-time wallpaper management without app updates

### 📱 User Experience
- **Splash Screen**: Animated logo with smooth transitions
- **Responsive Grid Layout**: Optimized for different screen sizes
- **Infinite Scroll**: Smooth loading of wallpapers
- **Full Preview**: Immersive wallpaper preview experience

### 💰 Monetization
- **Banner Ads**: Professional placement at bottom of screens
- **Rewarded Video Ads**: Required for downloads and wallpaper setting
- **Smart Ad Refresh**: Banner ads refresh naturally during scrolling

## Tech Stack

- **Frontend**: Flutter 3.10+
- **Backend**: Firebase (Firestore + Storage)
- **Ads**: Google Mobile Ads
- **State Management**: Provider
- **Image Caching**: Cached Network Image
- **Animations**: Lottie

## Firebase Setup

### 1. Firestore Database Structure
```javascript
// Collection: wallpapers
{
  "wallpaper_code": "WALL123",
  "url": "https://firebasestorage.googleapis.com/...",
  "category": "Minimal",
  "tags": ["black", "amoled", "clean"],
  "description": "Beautiful minimal wallpaper",
  "created_at": Timestamp,
  "downloads": 0
}
```

### 2. Firebase Storage
- Organize wallpapers in folders by category
- Use descriptive filenames
- Optimize images for mobile devices

### 3. Security Rules
```javascript
// Firestore Rules
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /wallpapers/{document} {
      allow read: if true;
      allow write: if false; // Only admin can write
    }
  }
}

// Storage Rules
rules_version = '2';
service firebase.storage {
  match /b/{bucket}/o {
    match /{allPaths=**} {
      allow read: if true;
      allow write: if false; // Only admin can upload
    }
  }
}
```

## Ad Integration

### AdMob Setup
1. Create AdMob account
2. Add your app to AdMob
3. Replace test ad unit IDs in `lib/providers/ad_provider.dart`:
   ```dart
   static const String _bannerAdUnitId = 'YOUR_BANNER_AD_UNIT_ID';
   static const String _rewardedAdUnitId = 'YOUR_REWARDED_AD_UNIT_ID';
   ```
4. Update `android/app/src/main/AndroidManifest.xml` with your AdMob App ID

## Installation & Setup

### Prerequisites
- Flutter SDK 3.10+
- Firebase project
- AdMob account

### Steps
1. Clone the repository
2. Run `flutter pub get`
3. Set up Firebase:
   - Add `google-services.json` to `android/app/`
   - Add `GoogleService-Info.plist` to `ios/Runner/`
4. Configure AdMob IDs
5. Run `flutter run`

## Promotion Strategy

### Instagram Marketing
1. **Content Creation**:
   - Showcase wallpapers in carousel posts
   - Create engaging reels with wallpaper previews
   - Add unique codes for each wallpaper

2. **Call-to-Action**:
   - "✨ Get this wallpaper in the HomeWalls app"
   - "Search by code: WALL123"
   - Include App Store/Play Store links

3. **Engagement Tactics**:
   - Limited-time exclusive wallpapers
   - Collaborate with theme pages
   - Weekly featured collections

### Growth Strategies
- **Email Collection**: Optional in-app email signup
- **Premium Features**: Ad-free experience for subscribers
- **User-Generated Content**: Allow users to submit wallpapers
- **Push Notifications**: New wallpaper alerts

## App Architecture

```
lib/
├── main.dart
├── models/
│   └── wallpaper_model.dart
├── providers/
│   ├── wallpaper_provider.dart
│   └── ad_provider.dart
├── screens/
│   ├── splash_screen.dart
│   ├── home_screen.dart
│   ├── category_screen.dart
│   ├── search_screen.dart
│   └── wallpaper_preview_screen.dart
├── widgets/
│   ├── category_card.dart
│   ├── wallpaper_card.dart
│   └── search_bar_widget.dart
└── utils/
    └── app_theme.dart
```

## Revenue Optimization

### Ad Placement Strategy
- **Banner Ads**: Bottom of home and category screens
- **Rewarded Ads**: Before downloads and wallpaper setting
- **Interstitial Ads**: Between category navigation (optional)

### User Retention
- **Daily Wallpapers**: Fresh content daily
- **Favorites System**: Save preferred wallpapers
- **Offline Mode**: Cache downloaded wallpapers
- **Social Sharing**: Share wallpapers with friends

## Performance Optimization

- **Image Caching**: Efficient memory management
- **Lazy Loading**: Load wallpapers on demand
- **Compression**: Optimize image sizes
- **Error Handling**: Graceful failure recovery

## Future Enhancements

- [ ] User accounts and favorites
- [ ] Wallpaper collections/playlists
- [ ] AI-powered recommendations
- [ ] Live wallpapers support
- [ ] Social features (ratings, comments)
- [ ] Premium subscription model
- [ ] Multi-language support

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Support

For support and questions, please contact [your-email@example.com]

---

**HomeWalls** - Beautiful wallpapers for your device 🎨