import 'package:flutter/material.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:provider/provider.dart';
import 'package:gallery_saver/gallery_saver.dart';
import 'package:wallpaper_manager_flutter/wallpaper_manager_flutter.dart';
import '../models/wallpaper_model.dart';
import '../providers/ad_provider.dart';
import '../providers/wallpaper_provider.dart';

class WallpaperPreviewScreen extends StatefulWidget {
  final WallpaperModel wallpaper;

  const WallpaperPreviewScreen({
    super.key,
    required this.wallpaper,
  });

  @override
  State<WallpaperPreviewScreen> createState() => _WallpaperPreviewScreenState();
}

class _WallpaperPreviewScreenState extends State<WallpaperPreviewScreen> {
  bool _isDownloading = false;
  bool _isSettingWallpaper = false;

  Future<void> _downloadWallpaper() async {
    final adProvider = context.read<AdProvider>();
    
    // Show rewarded ad first
    final adWatched = await adProvider.showRewardedAd();
    
    if (!adWatched) {
      _showSnackBar('Please watch the ad to download');
      return;
    }

    setState(() {
      _isDownloading = true;
    });

    try {
      final success = await GallerySaver.saveImage(
        widget.wallpaper.url,
        albumName: 'HomeWalls',
      );

      if (success == true) {
        // Increment download count
        context.read<WallpaperProvider>().incrementDownloadCount(widget.wallpaper.id);
        _showSnackBar('Wallpaper downloaded successfully!');
      } else {
        _showSnackBar('Failed to download wallpaper');
      }
    } catch (e) {
      _showSnackBar('Error downloading wallpaper: $e');
    } finally {
      setState(() {
        _isDownloading = false;
      });
    }
  }

  Future<void> _setWallpaper(int location) async {
    final adProvider = context.read<AdProvider>();
    
    // Show rewarded ad first
    final adWatched = await adProvider.showRewardedAd();
    
    if (!adWatched) {
      _showSnackBar('Please watch the ad to set wallpaper');
      return;
    }

    setState(() {
      _isSettingWallpaper = true;
    });

    try {
      final result = await WallpaperManagerFlutter().setwallpaperfromURL(
        widget.wallpaper.url,
        location,
      );

      if (result == 'Wallpaper set') {
        // Increment download count
        context.read<WallpaperProvider>().incrementDownloadCount(widget.wallpaper.id);
        _showSnackBar('Wallpaper set successfully!');
      } else {
        _showSnackBar('Failed to set wallpaper');
      }
    } catch (e) {
      _showSnackBar('Error setting wallpaper: $e');
    } finally {
      setState(() {
        _isSettingWallpaper = false;
      });
    }
  }

  void _showSnackBar(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  void _showSetWallpaperOptions() {
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) => Container(
        padding: const EdgeInsets.all(20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text(
              'Set Wallpaper',
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 20),
            ListTile(
              leading: const Icon(Icons.home),
              title: const Text('Home Screen'),
              onTap: () {
                Navigator.pop(context);
                _setWallpaper(WallpaperManagerFlutter.HOME_SCREEN);
              },
            ),
            ListTile(
              leading: const Icon(Icons.lock),
              title: const Text('Lock Screen'),
              onTap: () {
                Navigator.pop(context);
                _setWallpaper(WallpaperManagerFlutter.LOCK_SCREEN);
              },
            ),
            ListTile(
              leading: const Icon(Icons.phone_android),
              title: const Text('Both Screens'),
              onTap: () {
                Navigator.pop(context);
                _setWallpaper(WallpaperManagerFlutter.BOTH_SCREENS);
              },
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        iconTheme: const IconThemeData(color: Colors.white),
        actions: [
          IconButton(
            icon: const Icon(Icons.info_outline),
            onPressed: () {
              showDialog(
                context: context,
                builder: (context) => AlertDialog(
                  title: const Text('Wallpaper Info'),
                  content: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Code: ${widget.wallpaper.wallpaperCode}'),
                      Text('Category: ${widget.wallpaper.category}'),
                      Text('Downloads: ${widget.wallpaper.downloads}'),
                      if (widget.wallpaper.tags.isNotEmpty)
                        Text('Tags: ${widget.wallpaper.tags.join(', ')}'),
                    ],
                  ),
                  actions: [
                    TextButton(
                      onPressed: () => Navigator.pop(context),
                      child: const Text('Close'),
                    ),
                  ],
                ),
              );
            },
          ),
        ],
      ),
      extendBodyBehindAppBar: true,
      body: Stack(
        children: [
          // Wallpaper Image
          Center(
            child: CachedNetworkImage(
              imageUrl: widget.wallpaper.url,
              fit: BoxFit.contain,
              placeholder: (context, url) => const Center(
                child: CircularProgressIndicator(),
              ),
              errorWidget: (context, url, error) => const Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(
                      Icons.error_outline,
                      size: 64,
                      color: Colors.white54,
                    ),
                    SizedBox(height: 16),
                    Text(
                      'Failed to load image',
                      style: TextStyle(color: Colors.white54),
                    ),
                  ],
                ),
              ),
            ),
          ),
          // Bottom Action Buttons
          Positioned(
            bottom: 0,
            left: 0,
            right: 0,
            child: Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    Colors.transparent,
                    Colors.black.withOpacity(0.8),
                  ],
                ),
              ),
              child: SafeArea(
                child: Row(
                  children: [
                    Expanded(
                      child: ElevatedButton.icon(
                        onPressed: _isDownloading ? null : _downloadWallpaper,
                        icon: _isDownloading
                            ? const SizedBox(
                                width: 20,
                                height: 20,
                                child: CircularProgressIndicator(
                                  strokeWidth: 2,
                                  color: Colors.white,
                                ),
                              )
                            : const Icon(Icons.download),
                        label: Text(_isDownloading ? 'Downloading...' : 'Download'),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.white.withOpacity(0.2),
                          foregroundColor: Colors.white,
                          padding: const EdgeInsets.symmetric(vertical: 16),
                        ),
                      ),
                    ),
                    const SizedBox(width: 16),
                    Expanded(
                      child: ElevatedButton.icon(
                        onPressed: _isSettingWallpaper ? null : _showSetWallpaperOptions,
                        icon: _isSettingWallpaper
                            ? const SizedBox(
                                width: 20,
                                height: 20,
                                child: CircularProgressIndicator(
                                  strokeWidth: 2,
                                  color: Colors.white,
                                ),
                              )
                            : const Icon(Icons.wallpaper),
                        label: Text(_isSettingWallpaper ? 'Setting...' : 'Set Wallpaper'),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Theme.of(context).primaryColor,
                          foregroundColor: Colors.white,
                          padding: const EdgeInsets.symmetric(vertical: 16),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}